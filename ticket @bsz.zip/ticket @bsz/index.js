const { Client, GatewayIntentBits, Collection, Partials, EmbedBuilder } = require('discord.js');
const { token } = require('./config.json');
const { getGuildConfig } = require('./src/utils/db');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User]
});

client.commands = new Collection();

// Carregador de Comandos
const commandsPath = path.join(__dirname, 'src/commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
const commandsArray = [];

for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    client.commands.set(command.data.name, command);
    commandsArray.push(command.data.toJSON());
}

client.once('ready', async () => {
    await client.application.commands.set(commandsArray);
    console.log(`Bot logado como ${client.user.tag}`);
});

// Lógica para Mensagens (!pix) e Interações
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    if (message.content === '!pix') {
        const db = getGuildConfig(message.guild.id);
        
        const pixEmbed = new EmbedBuilder()
            .setTitle('💠 Pagamento via PIX')
            .setDescription(`${db.payments.message}`)
            .addFields({ name: 'Chave PIX', value: `\`\`\`${db.payments.pix_key}\`\`\`` })
            .setColor('#00FF7F')
            .setThumbnail('https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Logo_pix.png/600px-Logo_pix.png')
            .setFooter({ text: 'Após pagar, envie o comprovante aqui no ticket.' });

        await message.reply({ embeds: [pixEmbed] });
    }
});

client.on('interactionCreate', async (interaction) => {
    const interactionHandler = require('./src/events/interactionCreate');
    await interactionHandler(interaction);
});

client.login(token);
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel')
        .setDescription('Painel Administrativo')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('Painel de Controle Central')
            .setDescription('Gerencie o sistema de tickets, pagamentos e permissões.')
            .setColor('#2B2D31');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('btn_ticket_menu').setLabel('Ticket').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('conf_ticket_logs').setLabel('Logs/Canais').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('conf_ticket_cargos').setLabel('Cargos').setStyle(ButtonStyle.Secondary), // Novo Botão
            new ButtonBuilder().setCustomId('btn_pagamentos_menu').setLabel('Pagamentos').setStyle(ButtonStyle.Secondary)
        );

        if (interaction.isButton()) return await interaction.update({ embeds: [embed], components: [row] });
        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function handleTicketButton(interaction) {
    const embed = new EmbedBuilder()
        .setTitle('Configurações de Designer e Painel')
        .setDescription('Personalize a mensagem do ticket e publique o painel público.')
        .setColor('#2B2D31');

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('conf_ticket_designer')
            .setLabel('Designer')
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId('envia_painel_publico')
            .setLabel('Publicar Painel')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId('voltar_painel_principal')
            .setLabel('Voltar')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.update({ 
        embeds: [embed], 
        components: [row] 
    });
}

module.exports = { handleTicketButton };
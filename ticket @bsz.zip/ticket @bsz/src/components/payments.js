const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function handlePaymentButton(interaction) {
    const embed = new EmbedBuilder()
        .setTitle('Configurações de Pagamentos')
        .setDescription('Configure os dados de recebimento e mensagens automáticas.')
        .setColor('#00FF7F') // Verde para pagamentos
        .setFooter({ text: 'Módulo Financeiro' });

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('conf_pix_data')
            .setLabel('Configurar PIX')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId('voltar_painel_principal')
            .setLabel('Voltar')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.update({ 
        embeds: [embed], 
        components: [row] 
    });
}

module.exports = { handlePaymentButton };
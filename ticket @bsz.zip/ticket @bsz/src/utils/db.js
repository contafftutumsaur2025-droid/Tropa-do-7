const fs = require('fs');
const path = require('path');
const dbPath = path.resolve(__dirname, '../../database.json');

module.exports = {
    getGuildConfig: (guildId) => {
        if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}));
        let data = {};
        try {
            data = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
        } catch (e) {
            data = {};
        }

        // Se o servidor não existe ou faltam partes, nós criamos o padrão
        if (!data[guildId]) data[guildId] = {};
        if (!data[guildId].ticket) {
            data[guildId].ticket = { 
                title: "Atendimento", 
                desc: "Abra seu ticket", 
                color: "#2B2D31", 
                logs: null, 
                categoria: null,
                buttonName: "Abrir Ticket"
            };
        }
        if (!data[guildId].payments) {
            data[guildId].payments = { 
                pix_key: "Não definida", 
                message: "Efetue o pagamento via PIX para prosseguir." 
            };
        }

        // Salva imediatamente para evitar erros de undefined na próxima leitura
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 4));
        return data[guildId];
    },
    updateGuildConfig: (guildId, newData) => {
        const data = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
        data[guildId] = { ...data[guildId], ...newData };
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 4));
    }
};
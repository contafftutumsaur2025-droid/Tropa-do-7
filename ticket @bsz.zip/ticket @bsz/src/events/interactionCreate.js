const { 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder, 
    EmbedBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ChannelType, 
    PermissionFlagsBits,
    AttachmentBuilder
} = require('discord.js');

const { getGuildConfig, updateGuildConfig } = require('../utils/db');
const { handleTicketButton } = require('../components/tickets');
const { handlePaymentButton } = require('../components/payments');
const transcript = require('discord-html-transcripts');

module.exports = async (interaction) => {
    const db = getGuildConfig(interaction.guild.id);

    // 1. COMANDOS SLASH
    if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (command) await command.execute(interaction);
    }

    // 2. GERENCIAMENTO DE BOTÕES
    if (interaction.isButton()) {
        const staffRoleId = db.ticket.staff_role;
        const hasStaffRole = staffRoleId ? interaction.member.roles.cache.has(staffRoleId) : interaction.member.permissions.has(PermissionFlagsBits.Administrator);

        if (interaction.customId === 'btn_ticket_menu') return await handleTicketButton(interaction);
        if (interaction.customId === 'btn_pagamentos_menu') return await handlePaymentButton(interaction);
        if (interaction.customId === 'voltar_painel_principal') {
            const painelCommand = interaction.client.commands.get('painel');
            return await painelCommand.execute(interaction);
        }

        // --- CONFIGURAÇÕES ---
        if (interaction.customId === 'conf_ticket_cargos') {
            const modal = new ModalBuilder().setCustomId('modal_ticket_cargos').setTitle('Cargos da Staff');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('staff_role_id').setLabel("ID do Cargo Staff").setValue(db.ticket.staff_role || "").setStyle(1).setRequired(true)));
            return await interaction.showModal(modal);
        }

        if (interaction.customId === 'conf_ticket_logs') {
            const modal = new ModalBuilder().setCustomId('modal_ticket_logs').setTitle('Configurar Logs e Canais');
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('log_aberto').setLabel("ID: Log Ticket Aberto").setValue(db.ticket.log_aberto || "").setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('log_assumido').setLabel("ID: Log Ticket Assumido").setValue(db.ticket.log_assumido || "").setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('log_fechado').setLabel("ID: Log Ticket Fechado").setValue(db.ticket.log_fechado || "").setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('log_transcript').setLabel("ID: Log Transcripts").setValue(db.ticket.log_transcript || "").setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('categoria_id').setLabel("ID Categoria dos Tickets").setValue(db.ticket.categoria || "").setStyle(1))
            );
            return await interaction.showModal(modal);
        }

        if (interaction.customId === 'conf_ticket_designer') {
            const modal = new ModalBuilder().setCustomId('modal_ticket_designer').setTitle('Configurar Designer');
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('tit').setLabel("Titulo").setValue(db.ticket.title || "").setStyle(1).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desc').setLabel("Descricao").setValue(db.ticket.desc || "").setStyle(2).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('cor').setLabel("Cor Hex").setValue(db.ticket.color || "#2B2D31").setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('banner').setLabel("Link do Banner").setValue(db.ticket.banner || "").setRequired(false).setStyle(1)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('btn_nome').setLabel("Nome do Botao").setValue(db.ticket.buttonName || "Abrir Ticket").setStyle(1))
            );
            return await interaction.showModal(modal);
        }

        if (interaction.customId === 'envia_painel_publico') {
            const modal = new ModalBuilder().setCustomId('modal_escolher_canal_painel').setTitle('Enviar Painel');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('canal_alvo_id').setLabel("ID do Canal").setStyle(1).setRequired(true)));
            return await interaction.showModal(modal);
        }

        // --- AÇÕES DO TICKET ---
        if (interaction.customId === 'trigger_abrir_ticket') {
            const modal = new ModalBuilder().setCustomId('modal_motivo_ticket').setTitle('Motivo da Abertura');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('txt_motivo').setLabel("Motivo").setStyle(2).setRequired(true)));
            return await interaction.showModal(modal);
        }

        if (interaction.customId === 'assumir_ticket') {
            if (!hasStaffRole) return interaction.reply({ content: '❌ Apenas a staff configurada pode assumir.', ephemeral: true });
            
            await interaction.reply({ content: `✅ Atendimento iniciado por ${interaction.user}!` });
            const logAssumido = interaction.guild.channels.cache.get(db.ticket.log_assumido);
            if (logAssumido) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🛠️ Log: Ticket Assumido')
                    .setColor('#5865F2')
                    .setThumbnail(interaction.user.displayAvatarURL())
                    .addFields(
                        { name: 'Staff Responsável', value: `${interaction.user.tag} (\`${interaction.user.id}\`)`, inline: true },
                        { name: 'Canal do Ticket', value: `${interaction.channel}`, inline: true },
                        { name: 'Horário', value: `<t:${Math.floor(Date.now() / 1000)}:f>` }
                    ).setTimestamp();
                await logAssumido.send({ embeds: [logEmbed] });
            }
        }

        if (interaction.customId === 'fechar_ticket') {
            if (!hasStaffRole) return interaction.reply({ content: '❌ Sem permissão para fechar.', ephemeral: true });

            await interaction.reply({ content: '🔒 Gerando transcript e encerrando canal...' });

            const logFechado = interaction.guild.channels.cache.get(db.ticket.log_fechado);
            const logTranscript = interaction.guild.channels.cache.get(db.ticket.log_transcript);

            const file = await transcript.createTranscript(interaction.channel, {
                limit: -1,
                fileName: `transcript-${interaction.channel.name}.html`,
                returnType: 'attachment',
                poweredBy: false
            });

            const logEmbed = new EmbedBuilder()
                .setTitle('🔒 Log: Ticket Encerrado')
                .setColor('#ED4245')
                .addFields(
                    { name: '👤 Fechado por', value: `${interaction.user.tag} (\`${interaction.user.id}\`)`, inline: true },
                    { name: '📂 Canal', value: `\`#${interaction.channel.name}\``, inline: true },
                    { name: '📅 Data', value: `<t:${Math.floor(Date.now() / 1000)}:D>` }
                ).setTimestamp();

            if (logFechado) await logFechado.send({ embeds: [logEmbed] });
            if (logTranscript) await logTranscript.send({ content: `📄 Transcript de \`${interaction.channel.name}\`:`, files: [file] });

            setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
        }

        if (interaction.customId === 'notificar_usuario') {
            if (!hasStaffRole) return interaction.reply({ content: '❌ Sem permissão.', ephemeral: true });
            return await interaction.channel.send({ content: `🔔 <@${interaction.channel.topic}>, a equipe aguarda sua resposta!` });
        }
    }

    // 3. MODAIS SUBMIT
    if (interaction.isModalSubmit()) {
        if (interaction.customId === 'modal_ticket_cargos') {
            db.ticket.staff_role = interaction.fields.getTextInputValue('staff_role_id');
            updateGuildConfig(interaction.guild.id, db);
            return await interaction.reply({ content: '✅ Cargo salvo!', ephemeral: true });
        }

        if (interaction.customId === 'modal_ticket_logs') {
            db.ticket.log_aberto = interaction.fields.getTextInputValue('log_aberto');
            db.ticket.log_assumido = interaction.fields.getTextInputValue('log_assumido');
            db.ticket.log_fechado = interaction.fields.getTextInputValue('log_fechado');
            db.ticket.log_transcript = interaction.fields.getTextInputValue('log_transcript');
            db.ticket.categoria = interaction.fields.getTextInputValue('categoria_id');
            updateGuildConfig(interaction.guild.id, db);
            return await interaction.reply({ content: '✅ Logs salvos!', ephemeral: true });
        }

        if (interaction.customId === 'modal_ticket_designer') {
            db.ticket.title = interaction.fields.getTextInputValue('tit');
            db.ticket.desc = interaction.fields.getTextInputValue('desc');
            db.ticket.color = interaction.fields.getTextInputValue('cor');
            db.ticket.banner = interaction.fields.getTextInputValue('banner');
            db.ticket.buttonName = interaction.fields.getTextInputValue('btn_nome');
            updateGuildConfig(interaction.guild.id, db);
            return await interaction.reply({ content: '✅ Designer salvo!', ephemeral: true });
        }

        if (interaction.customId === 'modal_escolher_canal_painel') {
            const canalId = interaction.fields.getTextInputValue('canal_alvo_id');
            const targetChannel = interaction.guild.channels.cache.get(canalId);
            if (!targetChannel) return interaction.reply({ content: '❌ Canal inválido.', ephemeral: true });

            const publicEmbed = new EmbedBuilder()
                .setTitle(db.ticket.title || "Suporte")
                .setDescription(db.ticket.desc || "Abra um ticket")
                .setColor(db.ticket.color || '#2B2D31');
            if (db.ticket.banner) publicEmbed.setImage(db.ticket.banner);

            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('trigger_abrir_ticket').setLabel(db.ticket.buttonName || 'Abrir Ticket').setStyle(ButtonStyle.Primary));
            await targetChannel.send({ embeds: [publicEmbed], components: [row] });
            return await interaction.reply({ content: '✅ Painel publicado!', ephemeral: true });
        }

        if (interaction.customId === 'modal_motivo_ticket') {
            const motivo = interaction.fields.getTextInputValue('txt_motivo');
            const staffId = db.ticket.staff_role;

            // --- CORREÇÃO DO ERRO INVALID TYPE ---
            const permissionOverwrites = [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles] }
            ];

            // Só adiciona se o ID for válido e existir no servidor
            if (staffId && interaction.guild.roles.cache.has(staffId)) {
                permissionOverwrites.push({ id: staffId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles] });
            }

            const channel = await interaction.guild.channels.create({
                name: `ticket-${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: db.ticket.categoria || null,
                topic: interaction.user.id,
                permissionOverwrites: permissionOverwrites
            });

            const welcomeEmbed = new EmbedBuilder()
                .setTitle(`${db.ticket.title}`)
                .setDescription(`Bem-vindo ${interaction.user}!\n\n**Motivo:**\n\`\`\`${motivo}\`\`\``)
                .setColor(db.ticket.color || '#2B2D31')
                .setTimestamp();

            const rowActions = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('assumir_ticket').setLabel('Assumir').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('fechar_ticket').setLabel('Fechar').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('notificar_usuario').setLabel('Notificar').setStyle(ButtonStyle.Primary)
            );

            await channel.send({ content: `${interaction.user} ${staffId ? `| <@&${staffId}>` : ''}`, embeds: [welcomeEmbed], components: [rowActions] });
            
            // LOG ABERTURA
            const logAberto = interaction.guild.channels.cache.get(db.ticket.log_aberto);
            if (logAberto) {
                const logEmbed = new EmbedBuilder()
                    .setAuthor({ name: `Novo Ticket`, iconURL: interaction.user.displayAvatarURL() })
                    .setColor('#57F287')
                    .addFields(
                        { name: '👤 Usuário', value: `${interaction.user.tag} (\`${interaction.user.id}\`)`, inline: true },
                        { name: '📂 Canal', value: `${channel}`, inline: true },
                        { name: '📝 Motivo', value: `\`\`\`${motivo}\`\`\`` }
                    ).setTimestamp();
                await logAberto.send({ embeds: [logEmbed] });
            }
            return await interaction.reply({ content: `✅ Ticket: ${channel}`, ephemeral: true });
        }
    }
};